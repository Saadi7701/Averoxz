const express = require("express");
const router = express.Router();
const {
  createStore,
  getAllStores,
  getStoreByVendor,
  getMyStore,
  updateStore,
  deleteStore,
  getStoreStats
} = require("../controllers/storeController");
const { protect, vendorOnly } = require("../middleware/authMiddleware");

// Public routes
router.get("/", getAllStores);
router.get("/vendor/:vendorId", getStoreByVendor);

// Protected vendor routes
router.post("/", protect, vendorOnly, createStore);
router.get("/my-store", protect, vendorOnly, getMyStore);
router.put("/", protect, vendorOnly, updateStore);
router.delete("/", protect, vendorOnly, deleteStore);
router.get("/stats", protect, vendorOnly, getStoreStats);

module.exports = router;

