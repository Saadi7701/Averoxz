const User = require("../models/User");
const Product = require("../models/Product");

exports.getVendorProfile = async (req, res) => {
  try {
    const vendor = await User.findById(req.params.id).select("-password");
    if (vendor && vendor.role === "vendor") {
      res.json(vendor);
    } else {
      res.status(404).json({ message: "Vendor not found" });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getVendorProducts = async (req, res) => {
  try {
    const products = await Product.find({ vendor: req.params.id });
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
