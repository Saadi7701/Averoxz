import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Navigate, useLocation } from 'react-router-dom';
import { checkAuth } from '../store/slices/authSlice';

const ProtectedRoute = ({ children, requireAuth = true, allowedRoles = [] }) => {
  const dispatch = useDispatch();
  const location = useLocation();
  const { user, isAuthenticated, isLoading, token } = useSelector((state) => state.auth);

  useEffect(() => {
    // Check authentication status if we have a token but no user
    if (token && !user && !isLoading) {
      dispatch(checkAuth());
    }
  }, [dispatch, token, user, isLoading]);

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="w-8 h-8 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto mb-4" />
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  // If authentication is required but user is not authenticated
  if (requireAuth && !isAuthenticated) {
    // Store the attempted location for redirect after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If user is authenticated but doesn't have required role
  if (requireAuth && isAuthenticated && allowedRoles.length > 0) {
    if (!allowedRoles.includes(user?.role)) {
      return <Navigate to="/" replace />;
    }
  }

  // If authentication is not required but user is authenticated, allow access
  return children;
};

export default ProtectedRoute;

