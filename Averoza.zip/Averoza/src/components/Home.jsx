import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../store/slices/productSlice";
import { addToCart } from "../store/slices/cartSlice";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Search, Star, Heart } from "lucide-react";
import SearchBar from "./SearchBar";

const featuredProducts = [
  {
    title: "Elegant Evening Wear",
    subtitle: "Shop Now",
    image:
      "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Sharp Business Attire",
    subtitle: "Shop Now",
    image:
      "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Casual Street Style",
    subtitle: "Shop Now",
    image:
      "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=400&q=80",
  },
  {
    title: "Luxury Handbags",
    subtitle: "Shop Now",
    image:
      "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=400&q=80",
  },
];

const vendors = [
  {
    name: "Fashion Hub",
    image:
      "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=400&q=80",
    rating: 4.8,
    products: 150,
  },
  {
    name: "Tech Store",
    image:
      "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?auto=format&fit=crop&w=400&q=80",
    rating: 4.9,
    products: 89,
  },
  {
    name: "Home & Garden",
    image:
      "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?auto=format&fit=crop&w=400&q=80",
    rating: 4.7,
    products: 203,
  },
  {
    name: "Sports World",
    image:
      "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=400&q=80",
    rating: 4.6,
    products: 127,
  },
];

const Home = () => {
  const [showNavbar, setShowNavbar] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { products = [], isLoading } = useSelector((state) => state.products || {});
  const { user } = useSelector((state) => state.auth || {});
  const { totalItems = 0 } = useSelector((state) => state.cart || {});

  useEffect(() => {
    try {
      dispatch(fetchProducts());
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }, [dispatch]);

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (e.clientY < 40) setShowNavbar(true);
      else setShowNavbar(false);
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  const handleAddToCart = (product) => {
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      dispatch(addToCart({ productId: product._id, quantity: 1 }));
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Top Navbar */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: showNavbar ? 0 : -100 }}
        transition={{ duration: 0.3 }}
        className="fixed top-0 left-0 w-full z-50 bg-black/80 backdrop-blur-md border-b border-white/10"
      >
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-6">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="text-white text-xl font-bold cursor-pointer"
              onClick={() => navigate("/")}
            >
              Averoxz
            </motion.div>
            <div className="hidden md:flex gap-6">
              {["Home", "Explore", "Vendors", "Deals"].map((item) => (
                <motion.button
                  key={item}
                  whileHover={{ scale: 1.05 }}
                  className="text-white/80 hover:text-white transition-colors"
                  onClick={() => {
                    if (item === "Home") navigate("/");
                    else if (item === "Explore") navigate("/search");
                    else if (item === "Vendors") navigate("/signup?type=vendor");
                  }}
                >
                  {item}
                </motion.button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              className="relative p-2 text-white/80 hover:text-white"
              onClick={() => navigate("/cart")}
            >
              <ShoppingCart size={20} />
              {totalItems > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center text-xs bg-red-500">
                  {totalItems}
                </Badge>
              )}
            </motion.button>
            {user ? (
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="px-4 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700 transition-colors"
                onClick={() => navigate("/profile")}
              >
                Profile
              </motion.button>
            ) : (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => navigate("/login")}
                  className="bg-transparent text-white hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:text-white"
                >
                  Login
                </Button>
                <Button
                  size="sm"
                  onClick={() => navigate("/signup")}
                  className="bg-transparent text-white hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:text-white"
                >
                  Sign Up
                </Button>
              </div>
            )}
          </div>
        </div>
      </motion.nav>

      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="pt-20 pb-12 px-6"
      >
        <div className="max-w-6xl mx-auto text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold text-white mb-6"
          >
            Welcome to{" "}
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Averoxz
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-xl text-white/80 mb-8 max-w-2xl mx-auto"
          >
            Discover amazing products from trusted vendors worldwide. Your
            one-stop marketplace for everything you need.
          </motion.p>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="max-w-2xl mx-auto mb-8"
          >
            <SearchBar />
          </motion.div>

          {/* Hero CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-3 rounded-xl"
              onClick={() => navigate("/search")}
            >
              Start Shopping
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="bg-transparent text-white hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:text-white px-8 py-3 rounded-xl"
              onClick={() => navigate("/signup?type=vendor")}
            >
              Become a Vendor
            </Button>
          </motion.div>
        </div>
      </motion.div>

      {/* Featured Categories */}
      <motion.section
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="px-6 py-12"
      >
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            Featured Categories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ scale: 1.05, y: -5 }}
                viewport={{ once: true }}
                className="group cursor-pointer"
                onClick={() => navigate("/search")}
              >
                <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4">
                      <h3 className="text-white font-semibold text-lg">
                        {category.title}
                      </h3>
                      <p className="text-white/80 text-sm">
                        {category.subtitle}
                      </p>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Latest Products */}
      <motion.section
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="px-6 py-12"
      >
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            Latest Products
          </h2>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <div key={index} className="animate-pulse">
                  <div className="bg-white/10 rounded-lg h-64 mb-4"></div>
                  <div className="bg-white/10 rounded h-4 mb-2"></div>
                  <div className="bg-white/10 rounded h-4 w-2/3"></div>
                </div>
              ))}
            </div>
          ) : products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.slice(0, 8).map((product, index) => (
                <motion.div
                  key={product._id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.6 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  viewport={{ once: true }}
                >
                  <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden group">
                    <div className="relative">
                      <div className="w-full h-48 bg-white/20 flex items-center justify-center">
                        {product.images && product.images.length > 0 ? (
                          <img
                            src={product.images[0].url}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        ) : (
                          <div className="text-white/60 text-center">
                            <ShoppingCart className="w-12 h-12 mx-auto mb-2" />
                            <p className="text-sm">No Image</p>
                          </div>
                        )}
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="absolute top-2 right-2 p-2 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/30 transition-colors"
                      >
                        <Heart size={16} />
                      </motion.button>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="text-white font-semibold mb-2 line-clamp-2">
                        {product.name}
                      </h3>
                      <p className="text-white/60 text-sm mb-2 line-clamp-2">
                        {product.description}
                      </p>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-purple-400 font-bold text-lg">
                          ${product.price}
                        </span>
                        <div className="flex items-center gap-1">
                          <Star
                            size={14}
                            className="text-yellow-400 fill-current"
                          />
                          <span className="text-white/80 text-sm">4.5</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 bg-purple-600 hover:bg-purple-700"
                          onClick={() => navigate(`/product/${product._id}`)}
                        >
                          View Details
                        </Button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleAddToCart(product)}
                          className="p-2 bg-white/20 backdrop-blur-md rounded-lg text-white hover:bg-white/30 transition-colors"
                        >
                          <ShoppingCart size={16} />
                        </motion.button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <ShoppingCart className="w-16 h-16 text-white/60 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">No Products Yet</h3>
              <p className="text-white/60 mb-6">Be the first vendor to add products to our marketplace!</p>
              <Button
                onClick={() => navigate("/signup?type=vendor")}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                Become a Vendor
              </Button>
            </div>
          )}
        </div>
      </motion.section>

      {/* Featured Vendors */}
      <motion.section
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
        className="px-6 py-12"
      >
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            Featured Vendors
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {vendors.map((vendor, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                whileHover={{ scale: 1.05, y: -5 }}
                viewport={{ once: true }}
                className="group cursor-pointer"
              >
                <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden">
                  <div className="relative h-32 overflow-hidden">
                    <img
                      src={vendor.image}
                      alt={vendor.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  </div>
                  <CardContent className="p-4 text-center">
                    <h3 className="text-white font-semibold text-lg mb-2">
                      {vendor.name}
                    </h3>
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <Star
                        size={14}
                        className="text-yellow-400 fill-current"
                      />
                      <span className="text-white/80 text-sm">
                        {vendor.rating}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm mb-3">
                      {vendor.products} products
                    </p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-transparent text-white hover:bg-gradient-to-r hover:from-purple-600 hover:to-pink-600 hover:text-white"
                    >
                      Visit Store
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md border-t border-white/10 mt-12 pt-12 pb-8 px-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Averoxz</h3>
            <p className="text-white/60 text-sm leading-relaxed">
              Your trusted multi-vendor marketplace for quality products from
              verified sellers worldwide.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">
              Quick Links
            </h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li>
                <button onClick={() => navigate("/")} className="hover:text-white transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/search")} className="hover:text-white transition-colors">
                  Explore
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/cart")} className="hover:text-white transition-colors">
                  Cart
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/orders")} className="hover:text-white transition-colors">
                  Orders
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">
              For Vendors
            </h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li>
                <button onClick={() => navigate("/signup?type=vendor")} className="hover:text-white transition-colors">
                  Sell on Averoxz
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/vendor-dashboard")} className="hover:text-white transition-colors">
                  Vendor Dashboard
                </button>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Vendor Guidelines
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Resources
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4 text-white">Connect</h3>
            <ul className="space-y-2 text-sm text-white/60">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Twitter
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Facebook
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Instagram
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  LinkedIn
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="text-center text-white/40 text-sm mt-8 pt-8 border-t border-white/10">
          © {new Date().getFullYear()} Averoxz. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Home;

