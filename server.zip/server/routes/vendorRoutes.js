
const express = require("express");
const router = express.Router();
const { getVendorProfile, getVendorProducts } = require("../controllers/vendorController");

router.get("/:id", getVendorProfile);
router.get("/:id/products", getVendorProducts);

module.exports = router;


