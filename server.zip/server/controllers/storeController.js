const Store = require("../models/Store");
const User = require("../models/User");
const Product = require("../models/Product");

// Create a new store
exports.createStore = async (req, res) => {
  try {
    const { name, description, image, banner, address, contact, socialMedia, businessInfo } = req.body;
    
    // Check if vendor already has a store
    const existingStore = await Store.findOne({ vendor: req.user.id });
    if (existingStore) {
      return res.status(400).json({ message: "You already have a store" });
    }

    // Verify user is a vendor
    const user = await User.findById(req.user.id);
    if (user.role !== 'vendor') {
      return res.status(403).json({ message: "Only vendors can create stores" });
    }

    const store = await Store.create({
      vendor: req.user.id,
      name,
      description,
      image: image || '',
      banner: banner || '',
      address: address || {},
      contact: {
        phone: contact.phone,
        email: contact.email || user.email,
        website: contact.website || ''
      },
      socialMedia: socialMedia || {},
      businessInfo: businessInfo || {}
    });

    // Update user's vendor info with store reference
    await User.findByIdAndUpdate(req.user.id, {
      'vendorInfo.storeName': name,
      'vendorInfo.storeDescription': description,
      'vendorInfo.storeImage': image || ''
    });

    const populatedStore = await Store.findById(store._id).populate('vendor', 'username email');
    
    res.status(201).json(populatedStore);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all stores (public)
exports.getAllStores = async (req, res) => {
  try {
    const { page = 1, limit = 12, search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
    
    const query = { 'settings.isActive': true };
    
    // Add search functionality
    if (search) {
      query.$text = { $search: search };
    }
    
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;
    
    const stores = await Store.find(query)
      .populate('vendor', 'username email')
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .exec();
    
    const total = await Store.countDocuments(query);
    
    res.json({
      stores,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get store by vendor ID (public)
exports.getStoreByVendor = async (req, res) => {
  try {
    const { vendorId } = req.params;
    
    const store = await Store.findOne({ vendor: vendorId, 'settings.isActive': true })
      .populate('vendor', 'username email');
    
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    // Get store products
    const products = await Product.find({ 
      store: store._id, 
      status: { $in: ['active'] }
    })
    .populate('category', 'name')
    .sort({ createdAt: -1 })
    .limit(20);
    
    res.json({
      store,
      products
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get vendor's own store
exports.getMyStore = async (req, res) => {
  try {
    const store = await Store.findOne({ vendor: req.user.id })
      .populate('vendor', 'username email');
    
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    // Get store products with all statuses for vendor
    const products = await Product.find({ store: store._id })
      .populate('category', 'name')
      .sort({ createdAt: -1 });
    
    res.json({
      store,
      products
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update store
exports.updateStore = async (req, res) => {
  try {
    const { name, description, image, banner, address, contact, socialMedia, businessInfo, settings } = req.body;
    
    const store = await Store.findOne({ vendor: req.user.id });
    
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    // Update store fields
    if (name) store.name = name;
    if (description) store.description = description;
    if (image !== undefined) store.image = image;
    if (banner !== undefined) store.banner = banner;
    if (address) store.address = { ...store.address, ...address };
    if (contact) store.contact = { ...store.contact, ...contact };
    if (socialMedia) store.socialMedia = { ...store.socialMedia, ...socialMedia };
    if (businessInfo) store.businessInfo = { ...store.businessInfo, ...businessInfo };
    if (settings) store.settings = { ...store.settings, ...settings };
    
    const updatedStore = await store.save();
    
    // Update user's vendor info
    if (name || description || image) {
      const updateData = {};
      if (name) updateData['vendorInfo.storeName'] = name;
      if (description) updateData['vendorInfo.storeDescription'] = description;
      if (image !== undefined) updateData['vendorInfo.storeImage'] = image;
      
      await User.findByIdAndUpdate(req.user.id, updateData);
    }
    
    const populatedStore = await Store.findById(updatedStore._id).populate('vendor', 'username email');
    
    res.json(populatedStore);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete store
exports.deleteStore = async (req, res) => {
  try {
    const store = await Store.findOne({ vendor: req.user.id });
    
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    // Check if store has active products
    const activeProducts = await Product.countDocuments({ 
      store: store._id, 
      status: { $in: ['active'] }
    });
    
    if (activeProducts > 0) {
      return res.status(400).json({ 
        message: "Cannot delete store with active products. Please deactivate all products first." 
      });
    }
    
    await Store.findByIdAndDelete(store._id);
    
    res.json({ message: "Store deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get store statistics (vendor only)
exports.getStoreStats = async (req, res) => {
  try {
    const store = await Store.findOne({ vendor: req.user.id });
    
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    // Calculate real-time statistics
    const totalProducts = await Product.countDocuments({ store: store._id });
    const activeProducts = await Product.countDocuments({ 
      store: store._id, 
      status: 'active' 
    });
    const hiddenProducts = await Product.countDocuments({ 
      store: store._id, 
      status: 'hidden' 
    });
    const outOfStockProducts = await Product.countDocuments({ 
      store: store._id, 
      status: 'out_of_stock' 
    });
    
    // Update store stats
    store.stats.totalProducts = totalProducts;
    await store.save();
    
    res.json({
      totalProducts,
      activeProducts,
      hiddenProducts,
      outOfStockProducts,
      totalOrders: store.stats.totalOrders,
      totalRevenue: store.stats.totalRevenue,
      averageRating: store.stats.averageRating,
      totalReviews: store.stats.totalReviews
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

